from django.apps import AppConfig


class ExploreConfig(AppConfig):
    name = 'explore'
