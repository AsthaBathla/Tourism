from django.http import HttpResponse
from django.template import loader
from .models import Places
from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from django.views import generic
def index(request):
    return render(request,"explore/index.html",{})

def ab(request):
    return render(request,"explore/about.html",{})

def con(request):
    return render(request,"explore/contact.html",{})

def mount(request):
    return render(request,"explore/mountains.html",{})

def rel(request):
    return render(request,"explore/religious.html",{})
def his(request):
    return render(request,"explore/historical.html",{})

def ex(request):
    return render(request,"explore/exploree.html",{})
def de(request):
    return render(request,"explore/destinationd.html",{})
def ja(request):
    return render(request,"explore/destinationj.html",{})
def ag(request):
    return render(request,"explore/destinationa.html",{})





def srch(request):

#    query = request.GET.get("q", None)
#    qs = Places.objects.all()
#    if query is not None:
#        qs = qs.filter(
#                    Q(name__icontains=query)
#        )
#    context = {
#                " qs " : qs
#        }
    return render(request,'explore/search.html', {})



#def index(request):
 #  all_places = Places.objects.all()
  # template= loader.get_template('explore/index.html')
  # context = {
    # 'all_places': all_places,
#
 #  }
  # return HttpResponse(template.render(context,request))

 #  for place in all_places:
#        url = '/explore/' +  str(place.id)  + '/'
#        html += '<a href="'+ url +'">'+ Places.name +'</a><br>'
#        return HttpResponse(html)
def detail(request, place_id):
    #return HttpResponse("<h2>Details for place :"+ str(place_id)  + "</h2>")
    place = get_object_or_404(Places, pk=place_id)
    return render(request,'explore/detaill.html',{'place':place})



def beaches(request):
     return render(request,'explore/beaches.html')

class IndexView(generic.ListView):
     template_name = 'explore/list.html'
#context_object_name='all_albums'
     def get_queryset(self):
         return Places.objects.all()
