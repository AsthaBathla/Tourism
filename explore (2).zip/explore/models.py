from django.db import models

# Create your models here.
class Places(models.Model):
    name=models.CharField(max_length=120)
    description=models.TextField(blank=True,null=True)
    min_days=models.CharField(max_length=100)
    transport=models.TextField()
    image=models.FileField()
    def __str__(self):
        return  self.name

class Tourist_spot(models.Model):
    place=models.ForeignKey(Places,on_delete=models.CASCADE)
    t_name=models.CharField(max_length=120)
    about=models.TextField(blank=True,null=True)

    def __str__(self):
        return self.t_name
class Guide(models.Model):
    place=models.ForeignKey(Places,on_delete=models.CASCADE)
    guide_name=models.CharField(max_length=120)
    contactno=models.CharField(max_length=120)
    def __str__(self):
        return self.guide_name
