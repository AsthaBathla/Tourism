
from django.conf.urls import url

from . import views


urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^list/',views.IndexView.as_view(), name='list'),
    url(r'^(?P<place_id>[0-9]+)/$',views.detail,name='detail'),
    url(r'^beaches/',views.beaches, name='beaches'),
    url(r'^search/',views.srch, name="search"),
    url(r'^mountains/',views.mount, name='mountains'),
    url(r'^religious/',views.rel, name='religious'),
    url(r'^historical/',views.his, name='historical'),
    url(r'^contact/',views.con, name='contact'),
    url(r'^about/',views.ab, name='about'),
    url(r'^destinationd/',views.de, name='destinationd'),
    url(r'^destinationj/',views.ja, name='destinationj'),
    url(r'^destinationa/',views.ag, name='destinationa'),
    url(r'^exploree/',views.ex, name='exploree'),
]
